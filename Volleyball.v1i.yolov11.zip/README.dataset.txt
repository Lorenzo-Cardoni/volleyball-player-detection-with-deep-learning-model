# Volleyball > 2024-11-06 11:01pm
https://universe.roboflow.com/protom/volleyball-yb8bx

Provided by a Roboflow user
License: CC BY 4.0

